package com.sala1.sala1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sala1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
